
prog_var = 0

﻿#include<bits/stdc++.h>
 #include <unistd.h>
using namespace std;
struct renwu
{int gj,fy,js,mj,hx,zl;
int sx,lv,ex;
int mp;
double hp;
}Renwu[1];                
struct guaiwu
{
char name[10];
double hp;
int gj;
int fangyu;
char jn;
}Guaiwu[10];
char name[10];
int nhp=50,nsh=1,nmp=10;
int jlv[100];
int p,NMP=0;//胜利失败标识符
int jn1;//技能槽
double hd=0,SH=0;
int nex=0,EX_n=5;
int A1_1=0;
void  biao()
{cout<<"             "<<"人物"<<name<<' '<<"lv."<<Renwu[0].lv<<endl<<endl;
cout<<"当前剩余属性点"<<Renwu[0].sx<<endl;
cout<<"力量：  "<<Renwu[0].gj<<"		"<<"(输入1加点)"<<endl;
cout<<"敏捷：  "<<Renwu[0].mj<<"         "<<"(输入2加点)"<<endl;
cout<<"会心：  "<<Renwu[0].hx<<"	  "<<"(输入3加点)"<<endl;
cout<<"防御：  "<<Renwu[0].fy<<"		 "<<"(输入4加点)"<<endl;
cout<<"精神：  "<<Renwu[0].js<<"		"<<"(输入5加点)"<<endl;
cout<<"智力：  "<<Renwu[0].zl<<"		"<<"(输入6加点)"<<endl;
}
void qp()
{for(int i=1;i<=10;i++)
	cout<<endl;
}
void op()
{for(int i=1;i<=10;i++)
cout<<"@@@@@@@@@@@@@@@@@@@@@@@@@"<<endl;
}

void  zhanbiao(int a)
{
	cout<<name<<endl;
	cout<<"hp"<<Renwu[0].hp<<"+"<<hd<<endl;
	cout<<"mmp"<<Renwu[0].mp<<endl;
	if(a==0001)
	cout<<"1"<<"铁沙掌"<<endl;
else if(a==0002)
cout<<"1"<<"破魔剑"<<endl;
cout<<"11"<<"加强击（耗费10点ppm）";
cout<<"2"<<"逃跑"<<endl;	
}
 double tsz(int lv, renwu Renwu)
{
if(Renwu.gj<Renwu.fy||0.5*lv*Renwu.gj-Renwu.fy<=0) {
hd+=4*lv*Renwu.fy;return 5;}
else if(lv<3){hd+=3*lv*Renwu.fy ;return 0.7*lv*Renwu.gj-0.2*Renwu.fy;}
              else if(3<lv<7) {hd+=5*lv*Renwu.fy;   return 1.0*lv*Renwu.gj-0.3*Renwu.fy;}
                 else if(7<lv){ hd+=7*lv*Renwu.fy;return 1.2*lv*Renwu.gj-Renwu.fy;}
}
double pmj(int lv,renwu Renwu )
{double n=1;
double h=1.0/Renwu.hx;
if(Renwu.hx==0) return 1;
else if((rand()%int(h*100))>50||(rand()%int(h*100))<10)  {for(int i=1;i<=Renwu.hx;i++)n=n*1.2;cout<<"暴击"<<endl;}
if(lv<3)return (Renwu.hx*0.1+1)*n*0.8*lv*Renwu.gj;
else if(3<lv<7)return (Renwu.hx*0.1+1)*n*1.3*lv*Renwu.gj;
else if(7<lv)return (Renwu.hx*0.1+1)*n*1.6*lv*Renwu.gj;
}
int suiji(int a,double b)
{return rand()%int(b)+a;}
void chongkai()
{	
	memset(&Renwu[0],0,sizeof(Renwu[0]));
	 nhp=50,nsh=1,nmp=10;
         A1_1=0;
}

void   zhandou();
void G1_1(int ww,int wp);
void bj();
void sb();
void W_Gshanghai(double a,guaiwu &b);
void G_Wshanghai(double a);
void guaibiao(guaiwu a);
void Jn(int cz);
void jns(int a,int b);
double FY();
void G1_2();
void  gc();
void jiadian();





int main()
{      int a;
char b;
        
        label:
        srand((int)time(0));
	op();
	cout<<"                "<<"欢迎来到——时路灵雨"<<endl;


        cout<<"请输入你的名字";
        cin>>name;
        cout<<name<<"吗？"<<endl;
        cout<<"我记住了"<<endl;
        cout<<"那么，祝你好运"<<endl;

          op();

          cout<<"请选择你的初始技能（法师系暂不开放）"<<endl;
          cout<<"1.铁沙掌"<<endl;
          cout<<"2.破魔剑"<<endl;
          cout<<"请输入";
          cin>>a;
          if(a==1)jn1=0001,jlv[1]=1;
        else if(a==2)jn1=0002,jlv[1]=1;
        Renwu[0].sx=10;
        Renwu[0].lv=1;
        biao();
        a=0;
        while(Renwu[0].sx)
        {cin>>a;
        if(a==1)Renwu[0].gj++,Renwu[0].sx--,a=0;
        else if(a==2)Renwu[0].mj++,Renwu[0].sx--,a=0;
        else if(a==3)Renwu[0].hx++,Renwu[0].sx--,a=0;
        else if(a==4)Renwu[0].fy++,Renwu[0].sx--,a=0;
        else if(a==5)Renwu[0].js++,Renwu[0].sx--,a=0;
        else if(a==6)Renwu[0].zl++,Renwu[0].sx--,a=0;
        biao();
        }
        
        int OPO=15,OOO=20;
   G1_1(OPO,OOO);
   if(p==0)G1_2();
   if(p==1){p=0;goto label;}
   
return 0;
}
double  FY(guaiwu a)
{       a.gj=a.gj-Renwu[0].fy;
	if(hd>a.gj){hd-=a.gj ;return 0;}
	else {hd=0; return a.gj-hd;}
}
void  zhandou(renwu a,guaiwu &b)
{
int cz,t;
while(b.hp>0&&Renwu[0].hp>0)
{zhanbiao(jn1);
qp();
guaibiao(b);
WWWW:
cin>>cz;
bj();
Jn(cz);
if(NMP==1){NMP=0;goto WWWW;}
if(cz==2)cout<<"不能这样走了";
cout<<SH<<endl<<endl;
nsh=1;
W_Gshanghai(SH,b);
G_Wshanghai(FY(b));
}
sleep(1);
zhanbiao(jn1);
qp();
guaibiao(b);
}
void guaibiao(guaiwu a)
{cout<<a.name<<endl;
cout<<a.hp<<endl;
}
void bj()
{if(Renwu[0].hx==0)return;
	if(suiji(0,Renwu[0].hx)>5);
	{nsh=nsh*2;cout<<"暴击!!"<<endl;}	
}

void W_Gshanghai(double a,guaiwu &b)
{
	if(b.fangyu>=a) return;
       else 
       b.hp=b.hp+b.fangyu-a;

}
void Jn(int cz)
{
if(cz==1)jns(jn1,cz);
else if(cz==11&&Renwu[0].mp>=10)
{Renwu[0].mp-=10;nsh*=2;jns(jn1,cz);}
else cout<<"你的mp不够",NMP=1;
}
void jns(int a,int b)
{
	if(a==0001){cout<<"铁沙掌"<<endl;SH=nsh*tsz(jlv[b],Renwu[0]);}
	else if(a==0002){cout<<"破魔剑"<<endl;SH=nsh*pmj(jlv[b],Renwu[0]);
	}
} 


void G_Wshanghai(double a)
{
	Renwu[0].hp=Renwu[0].hp-a;
}
void gc()
{if(Renwu[0].ex+nex<EX_n){cout<<Renwu[0].ex<<"+"<<nex<<"/"<<EX_n<<endl,Renwu[0].ex+=nex,nex=0;
}
else {cout<<"Happy"<<endl<<"lv."<<Renwu[0].lv<<endl;
if(Renwu[0].lv<=10)Renwu[0].sx+=5;
else if(Renwu[0].lv<=20)Renwu[0].sx+=5;
if(Renwu[0].lv<=10)EX_n+=5;
else if(Renwu[0].lv<=20)EX_n+=10;
sleep(1);
cout<<"lv."<<++Renwu[0].lv<<endl;
Renwu[0].ex=0;}

biao();
jiadian();
}
 void jiadian()
 {int a;
 while(Renwu[0].sx)
        {cin>>a;
        if(a==1)Renwu[0].gj++,Renwu[0].sx--,a=0;
        else if(a==2)Renwu[0].mj++,Renwu[0].sx--,a=0;
        else if(a==3)Renwu[0].hx++,Renwu[0].sx--,a=0;
        else if(a==4)Renwu[0].fy++,Renwu[0].sx--,a=0;
        else if(a==5)Renwu[0].js++,Renwu[0].sx--,a=0;
        else if(a==6)Renwu[0].zl++,Renwu[0].sx--,a=0;
        biao();
        }
}









void  G1_1(int ww,int wp) 
{cout<<"——————————狂野之息1-1——————————"<<endl;
 int a,t=1,pqq,pp;
        double pppp=wp,gggg,x=ww,sh;
        nex=5;
        A1_1++;
        hd=0;
        Renwu[0].hp=nhp*Renwu[0].lv; 
        Renwu[0].mp=nmp*Renwu[0].lv;
while(pppp>0&&Renwu[0].hp>0)
        {gggg=x;
        zhanbiao(jn1);
        qp();
        pqq=1;
        cout<<""<<endl;
        cout<<"hp"<<pppp<<endl;
        cout<<"turn"<<' '<<t<<endl;
       
       PPPPP:

        cin>>a;
                   
                     if(a==1||a==11){if(jn1==0001){ sh=tsz(jlv[1],Renwu[0]);
                      }
                      else if(jn1==0002){ sh=pmj(jlv[1],Renwu[0]);}
                      	      
        cout<<"看招"<<endl;        	      
       
        op();
        if(a==1)pqq=1;
        else if(a==11&&Renwu[0].mp>=10){Renwu[0].mp-=10,pqq=2;}
        else {cout<<"你的mp不够"<<endl;
        goto PPPPP;}
 
                       pppp=pppp-(pqq*sh);
                       sh=0;
                       gggg-=Renwu[0].fy;
        	      if(hd<gggg)Renwu[0].hp=Renwu[0].hp+hd-gggg,hd=0;
        	      else  hd=hd-gggg;
        	      x++;
        } 
        else if(a==2)cout<<"一股莫名的力量阻止了你" ;
        }
qp();
if(pppp<=0) {cout<<"恭喜你啊，尚无知者。"<<endl<<"你听到了一个声音像摇篮一般飘荡而来，不知为何给你一种熟悉感。"<<endl;
				sleep(1);
				gc();
Renwu[0].hp=nhp*Renwu[0].lv;
cout<<"输入1重新挑战(怪会变强)"<<"输入2进入下一关"<<endl;
cin>>pp;
if(pp==1)x=15+A1_1*5,pppp=A1_1*40,G1_1(x,pppp);}
else if(Renwu[0].hp<=0&&A1_1==1){
         A1_1=0;
         cout<<"或许你真的变了。"<<endl;
 		cout<<"输入1重新挑战，输入2重新开始";
		cin>>pp;
		if(pp==1){pppp=20,x=15;
               Renwu[0].hp=nhp*Renwu[0].lv;
               G1_1(x,pppp);}
		else if(pp==2){chongkai();p=0;}}
		
else  {int OPOP;
cout<<"这里的怪打败了你，但你仍可以进入下一关"<<endl;
cout<<"输入2进入下一关";
                           iiii:
                           cin>>OPOP;
                           if(OPOP==2){
                           sleep(1);
                           cout<<"他的脸上露出了不解，似乎在说，我赢了啊，为什么会？"<<endl;
                            sleep(1);
                            qp();
                            cout<<"他根本不懂时间的力量"<<"对吧？"<<name<<endl;
                            op();
                            sleep(2);
                            Renwu[0].hp=nhp*Renwu[0].lv; return;}
                           else goto iiii;        }}
void G1_2()
{for(int i=1;i<=1000;i++)
{cout<<"@#￥%……！%&……@&……#×";
}
cout<<"——————————狂野之息1-2——————————"<<endl;
int pp;
guaiwu a;
hd=0;
strcpy(a.name,"mtt");
a.hp=500;a.fangyu=40;a.gj=0;
zhandou(Renwu[0],a);
if(a.hp<=0) cout<<"you win!!!!!!!!!!!!!!";
else cout<<"you low...."<<endl<<"输入1重新挑战，输入2重新开始";
cin>>pp;
if(pp==1){a.hp=1;
               Renwu[0].hp=nhp*Renwu[0].lv;
               G1_2();}
else if(pp==2){chongkai();p=1;}
}










